package ca.yorku.eecs.myapplication;

import junit.framework.Assert;

import org.junit.Test;

public class CipherTest
{
    @Test
    public void test()
    {
        Cipher cipher = new Cipher("1234");
        String encrypted = cipher.encrypt("THIS IS A TEST");
        System.out.println(encrypted);
        Assert.assertEquals("Encrypt", "UJLWAKVDBBWITV", encrypted);
        String encrypted2 = cipher.encrypt(encrypted);
        Assert.assertEquals("Decrypt", "VLO BMYHCDZMUX", encrypted2);
        System.out.println(encrypted2);
        String decrypted = cipher.decrypt(encrypted2);
        System.out.println(decrypted);
    }
}
