package ca.yorku.eecs.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onEncrypt(View v)
    {
        EditText data = (EditText)findViewById(R.id.data);
        String note = data.getText().toString();
        String key = ((EditText)findViewById(R.id.key)).getText().toString();
        Cipher cipher = new Cipher(key);
        try
        {
            data.setText(cipher.encrypt(note));
        }
        catch (IllegalArgumentException e)
        {
            Toast.makeText(this, "Invalid character in text!", Toast.LENGTH_LONG).show();
        }
    }

    public void onDecrypt(View v)
    {
        EditText data = (EditText)findViewById(R.id.data);
        String note = data.getText().toString();
        String key = ((EditText)findViewById(R.id.key)).getText().toString();
        Cipher cipher = new Cipher(key);
        try
        {
            data.setText(cipher.decrypt(note));
        }
        catch (IllegalArgumentException e)
        {
            Toast.makeText(this, "Invalid character in text!", Toast.LENGTH_LONG).show();
        }
    }

    private boolean isNotAlphanumeric(String s)
    {
        Pattern p = Pattern.compile("[^a-zA-Z0-9_\\-\\.]");
        return p.matcher(s).find();
    }
    public void onSave(View v)
    {
        try
        {
            String name = ((EditText) findViewById(R.id.file)).getText().toString();
            if (this.isNotAlphanumeric(name))
            {
                Toast.makeText(this, "Invalid character in file!", Toast.LENGTH_LONG).show();
            }
            else
            {
                File dir = this.getFilesDir();
                File file = new File(dir, name);
                if (file.exists())
                {
                    Toast.makeText(this, "File already exists!", Toast.LENGTH_LONG).show();
                }
                else
                {
                    FileWriter fw = new FileWriter(file);
                    fw.write(((EditText) findViewById(R.id.data)).getText().toString());
                    fw.close();
                    Toast.makeText(this, "Note saved.", Toast.LENGTH_LONG).show();
                }
            }
        }
        catch (Exception e)
        {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void onLoad(View v)
    {
        try
        {
            String name = ((EditText) findViewById(R.id.file)).getText().toString();
            if (this.isNotAlphanumeric(name))
            {
                Toast.makeText(this, "Invalid character in file!", Toast.LENGTH_LONG).show();
            }
            else
            {
                File dir = this.getFilesDir();
                File file = new File(dir, name);
                FileReader fr = new FileReader(file);

                String show = "";

                for (int c = fr.read(); c != -1; c = fr.read())
                {
                    show += (char) c;
                }
                fr.close();
                ((EditText) findViewById(R.id.data)).setText(show);
                Toast.makeText(this, "Note loaded.", Toast.LENGTH_LONG).show();
            }
        }
        catch (Exception e)
        {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
